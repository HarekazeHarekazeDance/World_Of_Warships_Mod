API_VERSION = 'API_v1.0'

contentSdk.registerShipMod('JSD708_HSF_Harekaze')