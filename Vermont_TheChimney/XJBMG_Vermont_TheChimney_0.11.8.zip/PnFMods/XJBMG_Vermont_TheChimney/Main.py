API_VERSION = 'API_v1.0'

contentSdk.registerShipMod('ASB110_Vermont')