API_VERSION = 'API_v1.0'
contentSdk.registerShipMod('BSB510_Thunderer')